<?php
namespace App\Controllers;
use CodeIgniter\Controller;

class Carrito extends Controller
{
    public function agregar()
    {
        $cantidad = (int) $this->request->getPost('cantidad');

        if ($cantidad <= 0) {
            return redirect()->back()->with('mensaje', 'La cantidad debe ser mayor a 0');
        }

        $producto = [
            'id' => $this->request->getPost('id'),
            'nombre' => $this->request->getPost('nombre'),
            'precio' => $this->request->getPost('precio'),
            'cantidad' => $cantidad
        ];

        $session = session();

        if (!$session->has('carrito')) {
            $session->set('carrito', []);
        }

        $carrito = $session->get('carrito');
        $id = $producto['id'];

        if (isset($carrito[$id])) {
            $carrito[$id]['cantidad'] += $producto['cantidad'];
        } else {
            $carrito[$id] = $producto;
        }

        $session->set('carrito', $carrito);

        return redirect()->to(base_url('productos'))->with('mensaje', 'Producto agregado al carrito');
    }

    public function ver()
    {
        $session = session();
        $data['carrito'] = $session->get('carrito') ?? [];

        echo view('carrito', $data);
    }
}
