<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top py-1">
    <a class="navbar-brand" href="<?= base_url() ?>"> 
        <img src="<?= base_url('assets/img/logo.jpg') ?>" class="img-fluid" style="height: 50px;">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#my-nav"
        aria-controls="my-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div id="my-nav" class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('productos') ?>">Productos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('carrito/ver') ?>">
                    Carrito (<?= esc($cantidadCarrito ?? 0) ?>)
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
   <br>
     <div class="alert alert-success">
        Pantalla de mensaje...
        <a href="#" class="badge badge-success">Ver Carrito</a>
     </div>


  
    <div class="quienesSomosTitulos row" style="text-align: center;">
        <h2>NUESTRO CATÁLOGO</h2>
    </div>
    <br>
    
    <div class="row g-3">

    <!-- Producto 1 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/whey_star.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Whey Protein Star-Nutrition</h5>
            <p class="card-text">Proteína de suero de leche de la mejor calidad. 25grs. de proteína por servicio. Contenido 1kg.</p>
            <p class="card-text">Precio: $25.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="1">
                <input type="hidden" name="nombre" value="Whey Protein Star-Nutrition">
                <input type="hidden" name="precio" value="25000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 2 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/creatina_on.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Creatina Optimal Nutrition</h5>
            <p class="card-text">Creatina pura, micronizada, sin sabor, alta absorción. Ideal para entrenamiento de fuerza. Contenido 317grs.</p>
            <p class="card-text">Precio: $18.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="2">
                <input type="hidden" name="nombre" value="Creatina Optimal Nutrition">
                <input type="hidden" name="precio" value="18000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 3 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/colageno_ena.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Colágeno ENA</h5>
            <p class="card-text">Variedad saborizada o sin sabor. Ideal para fortalecer las articulaciones y mejorar la recuperación ligamentaria y cartilaginosa.</p>
            <p class="card-text">Precio: $15.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="3">
                <input type="hidden" name="nombre" value="Colágeno ENA">
                <input type="hidden" name="precio" value="15000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 4 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/calleras_velites.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Calleras Velites</h5>
            <p class="card-text">Calleras ideales para gym/crossfit/ calistenia. De fibra de carbono. Alta resistencia y duracion.</p>
            <p class="card-text">Precio: $14.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="4">
                <input type="hidden" name="nombre" value="Calleras Velites">
                <input type="hidden" name="precio" value="14000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 5 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/rodillera_rehband.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Rodillera Rehband</h5>
            <p class="card-text">La mejor del mercado. Alta durabilidad y compresión. Colores a elección. Precio por unidad.</p>
            <p class="card-text">Precio: $20.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="5">
                <input type="hidden" name="nombre" value="Rodillera Rehband">
                <input type="hidden" name="precio" value="20000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 6 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/cinturon_rdx.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Cinturón RDX</h5>
            <p class="card-text">Para los entrenamientos más exigentes. Resistente y durable. Materiales de primera calidad.</p>
            <p class="card-text">Precio: $35.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="6">
                <input type="hidden" name="nombre" value="Cinturón RDX">
                <input type="hidden" name="precio" value="35000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 7 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/mancuernas_bodysolid.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Mancuernas BodySolid</h5>
            <p class="card-text">Mancuernas hexagonales de goma de alto impacto. Super durables. Precio por kg de peso.</p>
            <p class="card-text">Precio: $5.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="7">
                <input type="hidden" name="nombre" value="Mancuernas BodySolid">
                <input type="hidden" name="precio" value="5000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 8 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/banco_lupon.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Banco regulable Lupon</h5>
            <p class="card-text">De acero y aluminio. Diseño elegante y resistente. Apto para uso profesional. Espuma alta densidad.</p>
            <p class="card-text">Precio: $44.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="8">
                <input type="hidden" name="nombre" value="Banco regulable Lupon">
                <input type="hidden" name="precio" value="44000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>

<!-- Producto 9 -->
<div class="col-md-4">
    <div class="card h-100 d-flex flex-column">
        <img src="assets/img/barra_atx.jpg" class="card-img-top h-100" alt="...">
        <div class="card-body flex-grow-1">
            <h5 class="card-title">Barra olímpica ATX</h5>
            <p class="card-text">Con rodamientos calibrados. Peso reglamentario (20kg). Alto cimbreo y resiliencia. Apta para crossfit/halterofilia.</p>
            <p class="card-text">Precio: $180.000</p>
            <form action="<?= base_url('carrito/agregar') ?>" method="post">
                <input type="hidden" name="id" value="9">
                <input type="hidden" name="nombre" value="Barra olímpica ATX">
                <input type="hidden" name="precio" value="180000">
                <input type="hidden" name="cantidad" value="1">
                <button class="btn btn-primary" type="submit">Agregar al carrito</button>
            </form>
        </div>
    </div>
</div>


    <a href="index" style="text-align: center; width: 100%; margin-top: 20px;">Volver</a>
</div>



