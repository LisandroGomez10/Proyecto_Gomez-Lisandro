<body class="d-flex flex-column min-vh-100" style="background-color: rgb(150, 150, 150);">

<main class="flex-grow-1">
    <!-- Título con logotipo -->
<br>
    <div class="container">
        <div class="title row align-items-center rounded-2">
            <div class="titleLogo col-md-2 text-center text-md-left">
                <img src="assets/img/logo.jpg" alt="Logotipo de PowerSource Insumos" class="img-fluid mr-3 rounded-2">
            </div>
            <div class="col-md-10 text-center text-md-left">
                PowerSource Insumos
            </div>
        </div>
    </div>
<br>